# LCD_invaders
A Space Invaders like game on an LCD text shield. 

![](https://github.com/arduinocelentano/LCD_invaders/blob/master/lcdinvaders.jpg)
